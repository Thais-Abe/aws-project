def lambda_hello(event, context):
    return "Hello Lambda"